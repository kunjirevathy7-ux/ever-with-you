function checkPassword() {

  const password = document.getElementById("passwordInput").value;

  if (password === "09062003") 
    {

  document.getElementById("lockScreen").style.display = "none";

    document.getElementById("mainContent").style.display = "block";

    updateSlide();

  } else {

    alert("Wrong date baby 🥺 Try again!");

  }

}

const slides = [

  {
    title: "Our Future Together",

    text: "A little glimpse of the life we're creating together...",
img: "https://i.postimg.cc/sfMRC04r/d66222ca41ece880c5a65dd952956b2c.jpg"
  },

  {

    title: "How It All Started",

    text: "It all began with a simple hello that changed everything.from random chats toto endless laughter,story found its ",
img: "https://i.postimg.cc/m2cZVg5D/5d229e3cc61b70b4f39368d5726eb47c.jpg"
  },
  {
    title: "How It Going",
    text: "We do fight sometimes, get angry, even stop talking for a  while. But no matter what, we always find way to each other. Because this bond means more than any fight ever could.",
    img :"https://i.postimg.cc/tJJqKqRw/a4095fbcbf75587230649f21e08bbe40.jpg"
    },
  {

    title: "Forever With You",

    text: "Every moment with you feels magical.",
    img: "https://i.postimg.cc/QtRqb66Z/6d444c7fc868bfe85d7a94545cfebeeb.jpg"

  },
  {
  title:" Thank you  Everything ",
    text:"Thank you for always being  when I needed someone. You make moments feel special ust by being a part of them ",
    img:"https://i.postimg.cc/rF2JRP0Y/4ad27605aea18d7ce6f63b0cb1f02153.jpg"
  },
  {
    title:"One Last Thing",
    text:"Will you stame with me forever?",
    img: "https://i.postimg.cc/bvxN6dY5/8c6eb69d19a43bb957826206e987ff27.jpg"
    
    },

];

let index = 0;

function updateSlide() {

  document.getElementById("title").innerText = slides[index].title;

  document.getElementById("text").innerText = slides[index].text;
  document. getElementById("photo").src= slides[index].img;

}

function nextSlide() {

  index = (index + 1) % slides.length;

  updateSlide();

}

function prevSlide() {

  index = (index - 1 + slides.length) % slides.length;

  updateSlide();

}
